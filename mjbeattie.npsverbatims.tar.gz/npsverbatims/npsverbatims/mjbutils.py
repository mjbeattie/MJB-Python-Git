"""
mjbutils.py is a set of string handling and other functions.
@author  Matthew J. Beattie
@date    May 10, 2018
"""

import codecs
import re


def readtab(filename, encoding='utf-8'):
    """
    readtab() reads a tab-delimited file of phrases and sentences into a list
    :param filename: the name of the file to be read in (string)
    :param encoding:  the type of encoding for the input file.  Default is UTF-8
    :return: a list of strings
    """
    # Read in the text file
    f = codecs.open(filename, encoding=encoding)
    allText = f.read()

    # Strip out special characters
    allText = re.sub('\\n', "", allText)            # remove new line character
    allText = re.sub(u'\ufeff', "", allText)        # remove thorns
    #    allText = re.sub('\\t',"",allText)         # remove tabs
    allText = re.sub('\"', "", allText)             # remove backslashes

    # Write the comments into a list of strings
    posts = re.split('\\r', allText)
    records = []
    for post in posts:
        record = re.split('\\t', post)
        records.append(record)
    f.close()
    return records


def stringToFile(string, filename, encoding='utf-8'):
    """
    stringToFile() writes a string into a text file
    :param string:    Name of input string
    :param filename:  Name of output file
    :param encoding:  Desired encoding for the text file.  Defaults to UTF-8
    :return: nothing returned
    """
    fileOut = codecs.open(filename, 'w', encoding=encoding)
    print(string, file=fileOut)
    fileOut.close()
    return


def listToString(listin):
    """
    listToString() takes a list of items and writes them into a column
    that can be printed to a file.
    :param listin:  input list
    :return: string
    """
    strout = ""
    for item in listin:
        strout += item + '\n'
    return strout


def jaccarddist(list1, list2):
    """
    jaccarddist() takes two lists and calculates the Jaccard distance between them
    :param list1: input list 1
    :param list2: input list 2
    :return: Jaccard distance as a floating point value
    """
    s1 = set(list1)
    s2 = set(list2)
    if len(s1) == 0 and len(s2) == 0:
        return 0
    else:
        return len(s1.intersection(s2)) / len(s1.union(s2))
