"""
npsparse.py is a script that read in NPS verbatims and finds the Jaccard distance between them
Created on Mon Feb 26 19:57:34 2018

@author: mjbea
"""

from nltk import word_tokenize
import mjbutils
from nltk.corpus import stopwords
import logging
import importlib


# Setup logging for program
importlib.reload(logging)  # To stop repeated outputs in iPython
log = logging.getLogger("NPSPARSE")
log.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
formatter = logging.Formatter("%(asctime)s %(levelname)s:%(name)s %(message)s")
ch.setFormatter(formatter)
log.addHandler(ch)


# Read posts into a list
posts = mjbutils.readtab('nps_verbatims_cln.txt')

# Delete last two records, which have blanks
posts.pop()
posts.pop()

# Remove stopwords and punctuation from posts
log.info("Removing stopwords and punctuation from posts")
stops = stopwords.words('english')
verbatims = []
for post in posts:
    stripped = []
    tokens = word_tokenize(post[4])
    for token in tokens:
        if token.lower() not in stops and token.isalpha():
            stripped.append(token.lower())
    verbatims.append(stripped)
log.info("Completed removing stopwords and punctuation")


# Calculate the Jaccard index and store the results in a new list
log.info("Beginning Jaccard calculations")
output = []
i = 0
for i in range(0,len(verbatims)-2):
    if i % 10 == 0:  log.info("Calculating Jaccard distances for post " + str(i))
    j = 0
    for j in range(i+1,len(verbatims)-1):
        dist = round(mjbutils.jaccarddist(verbatims[i], verbatims[j]), 4)
        item = [i, j, dist]
        output.append(item)
        j += 1
    i += 1
log.info("Jaccard calculations complete")

# Sort the list of Jaccard indices and print to standard out
output = sorted(output, key=lambda x: x[2], reverse=True)
top100 = []
for i in range(0, 100):
    print(output[i])
