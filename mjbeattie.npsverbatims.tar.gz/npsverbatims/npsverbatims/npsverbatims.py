# Matthew J. Beattie
# DSA 5970
# NPS Verbatims Parsing
# March 13, 2018
#!/usr/bin/python
# coding=utf-8

"""
npsverbatims.py
Takes NPS verbatims and stores them into an SQLite DB.  Uses that DB to perform text analytics
to determine patterns and similarities among customer feedback items.

Created on Sun Feb 25 21:47:29 2018

@author: mjbea
"""

import re
import mjbutils


def CreateNPSDB():
    """ CreateDB()
        Creates an SQLite database to store the records read in from the NPS text file.
    """
    import sqlite3 as lite
    import sys

    try:
        con = lite.connect('npsverbatims.db')
        cur = con.cursor()

        cur.execute("DROP TABLE IF EXISTS verbatims")
        comString = "CREATE TABLE verbatims(recnum NUMBER, intdate TEXT, npsflag TEXT, role TEXT, verbatim TEXT)"

        cur.execute(comString)
        con.commit()
        con.close()

    except lite.Error as e:
        if con:
            con.rollback()
        print("Error %s:", e.args[0])
        sys.exit(1)

    finally:
        if con:
            con.close()


def PopulateNPSDB(recordList):
    """ PopulateDB()
        Stores the records read in from an NPS list into an SQLite DB.
    """
    import sqlite3 as lite
    import sys

    try:
        con = lite.connect('npsverbatims.db')
        cur = con.cursor()

        for currRec in recordList:
            if (len(currRec)==5):
                recnum = currRec[0]
                intdate = currRec[1]
                npsflag = currRec[2]
                role = currRec[3]
                verbatim = currRec[4]
                comString = "INSERT INTO verbatims VALUES('" + recnum + "','" + intdate + "','" + \
                            npsflag + "','" + role + "','" + verbatim + "')"
                cur.execute(comString)
                con.commit()
        con.close()

    except lite.Error as e:
        if con:
            con.rollback()
        print("Error %s:", e.args[0])
        sys.exit(1)

    finally:
        if con:
            con.close()


def Status():
    """ Status()
        Prints the row count and first five rows of the verbatims table in the npsverbatims
        database to standard out.
    """
    import sqlite3 as lite
    import sys

    try:
        # Print out the number of rows in the Arrests table using SQL
        con = lite.connect('npsverbatims.db')
        cur = con.cursor()
        comString = "SELECT count(*) from verbatims"
        cur.execute(comString)
        data = cur.fetchall()
        output = data[0]
        print("The number of rows in the verbatims table is", output[0])

        # Read the rows in Arrests into an array and print out the first five
        # elements separated by the thorn character
        comString = "SELECT * from verbatims"
        cur.execute(comString)
        data = cur.fetchall()
        stopNum = min(10, len(data))
        outString = ""
        for i in range(0, stopNum):
            print(data[i])
        con.close()

    except lite.Error as e:
        if con:
            con.rollback()
        print("Error %s:", e.args[0])
        sys.exit(1)

    finally:
        if con:
            con.close()


# Read text file into a list that can be stored in a database
recordList = mjbutils.readtab("nps_verbatims_cln.txt")

# Create database
print("Creating database in SQLite...")
CreateNPSDB()

# Insert arrest data into database
print("Populating verbatims table...")
PopulateNPSDB(recordList)

# Print status
print("Showing database status...")
Status()
