"""
scratchpad.py contains a script that creates a list of word frequencies and
a list of bigram frequencies from NPS score verbatims that were included in
responses to 2017 and 2018 NPS surveys at AT&T.  Note that this program expects
an explicit directory structure.  
"""


import nltk
from nltk.corpus import stopwords
import mjbutils

# Read in customer verbatims
recordList = mjbutils.readtab('nps_verbatims_cln.txt')
recordList.pop()
recordList.pop()

funVerbatims = []

# Create a list of verbatims for detractors
detractorVer = []
for record in recordList:
    if record[2] == 'DETRACTOR':
        detractorVer.append(record[4])

# Create a list of words found in detractors, don't include stop words
detractorWords = []
stops = stopwords.words('english')
for verbatim in detractorVer:
    words = nltk.word_tokenize(verbatim)
    for word in words:
        if word.lower() not in stops and word.isalpha():
            detractorWords.append(word.lower())

# Generate frequency of detractor words
fdist1 = nltk.FreqDist(detractorWords)

# Plot frequency of 50 most common detractor words
fdist1.plot(50, cumulative=True)

# Create a list of verbatims for promoters
promoterVer = []
for record in recordList:
    if record[2] == 'PROMOTER':
        promoterVer.append(record[4])

# Create a list of words found in promoters, don't include stop words
promoterWords = []
for verbatim in promoterVer:
    words = nltk.word_tokenize(verbatim)
    for word in words:
        if word.lower() not in stops and word.isalpha():
            promoterWords.append(word.lower())

# Generate frequency of detractor words
fdist2 = nltk.FreqDist(promoterWords)

# Plot frequency of 50 most common detractor words
fdist2.plot(50, cumulative=True)

# Output detractor and promoter word lists to files
dstr = mjbutils.listToString(detractorWords)
pstr = mjbutils.listToString(promoterWords)
dfile = mjbutils.stringToFile(dstr, 'detractorwords.txt')
pfile = mjbutils.stringToFile(pstr, 'promoterwords.txt')

# Create bigram lists and write to files
prombglist = list(nltk.bigrams(promoterWords))
pbgstr = ''
for bg in prombglist:
    pbgstr += bg[0] + bg[1] + '\n'

detbglist = list(nltk.bigrams(detractorWords))
dbgstr = ''
for bg in detbglist:
    dbgstr += bg[0] + bg[1] + '\n'

pbgfile = mjbutils.stringToFile(pbgstr, 'prombigrams.txt')
dbgfile = mjbutils.stringToFile(dbgstr, 'detbigrams.txt')
