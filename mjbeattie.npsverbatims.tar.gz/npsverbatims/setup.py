from setuptools import setup, find_packages

setup(
        name='npsverbatims',
        version='1.0',
        author='Matthew J. Beattie',
        author_email='mjbeattie@beattieco.com',
        packages=find_packages(exclude=('tests','docs'))
        )
